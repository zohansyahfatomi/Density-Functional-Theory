close all; clear all;
kB=8.6173324e-5;%8.617e-5; % eV/K  %1.3806488e-23; % J/K 
h=4.135665538e-15;%4.136e-15;% eV s %6.62606957e-34; % J s
%c=2.99792458e+10;%cm/s %%299792500;
%hc=h*c;
%0.000124
%hperkB=h/kB;
load ModeFreqP.txt
load ModeFreqV.txt
%Tsi=1685;
%Ef=input(' Ef   = '); % 3.4629961914 eV
T=[500:1:1685]'; % K
Np=length(ModeFreqP);
%vibp=ModeFreqP(:,1);
hnup=ModeFreqP(:,2); % eV
%nup=ModeFreqP(:,3); % cm^-1
%-------------
Nv=length(ModeFreqV);
%vibv=ModeFreqV(:,1);
hnuv=ModeFreqV(:,2); % eV
%nuv=ModeFreqV(:,3); % cm^-1
%-----------------
%Np=input(' Number of Atoms Np = ')
%Nv=Np-1
%Ecp=4.63/216%0.0544; % Ec = 4.63 eV
%Ecv=4.63/215
%E0p=0.040153431; % sigma(hnu)/3N
%E0v=0.039392684;
for i=1:length(T)
 %   Cp=exp(Np*Ecp/(kB*T(i)));
    for k=1:Np
        sump=0;
        Ap=hnup(k)/(kB*T(i));
        fp=hnup(k)/2;%+kB*T(i)*log(1-exp(-Ap));
        %-----
       % Ap=hnup(k)/(2*kB*T(i));
        %fp=log((exp(Ap)-exp(-Ap))/2);
        %f0p=exp(-hnup(k)/(kB*T(i)));
        %fp=hnup(k)/T(i)*f0p/(1-f0p)-kB*log(1-f0p);
        sump=sump+fp;
    end
    %Pvib=kB*T(i)*sump; %Np=3N
    Pvib=sump;
    FP(i,:)=[Pvib];
end
FPvib=FP;%+E0p;%/kB;
%----------------------
for i=1:length(T)
 %   Cp=exp(Np*Ecp/(kB*T(i)));
    for k=1:Nv
        sumv=0;
        Av=hnuv(k)/(kB*T(i));
        fv=hnuv(k)/2;%+kB*T(i)*log(1-exp(-Av));
        %Av=hnuv(k)/(2*kB*T(i));
        %fv=log((exp(Av)-exp(-Av))/2);
        %f0p=exp(-hnup(k)/(kB*T(i)));
        %fp=hnup(k)/T(i)*f0p/(1-f0p)-kB*log(1-f0p);
        sumv=sumv+fv;
    end
    %Vvib=kB*T(i)*sumv;
    Vvib=sumv;
    FV(i,:)=[Vvib];
end
FVvib=FV;%+E0v;%/kB;
%----------------------
%FormaFvib=215*(FVvib-FPvib)
FormaFvib=(FVvib-645/648*FPvib)
%FormaFvib=FVvib-215/216*FPvib;
figure(1)
plot(T,FormaFvib,'k','LineWidth',2)
xlabel('Temperature (K)')
ylabel('Vibrational Formation Free Energy (eV)')
saveas(gcf,'FormaFvibE0.png')
FormaFvibT=[T FormaFvib];
save FormaFvibE0.txt FormaFvibT -ascii
%-------------
figure(2)
plot(T,FP,'k','LineWidth',2)
hold on
plot(T,FV,'b','LineWidth',2)
xlabel('Temperature (K)')
ylabel('Vibrational Energy (eV)')
leg0=legend('Perfect','Vacancy');
set(leg0,'Location','NorthEast')
saveas(gcf,'Fvib.png')
FvibT=[T FormaFvib FP FV];
save FvibT.txt FvibT -ascii
%----------------
% FormVib=(FV-645/648*FP);
% figure(3)
% plot(T,FormVib,'k','LineWidth',2)
% xlabel('Temperature (K)')
% ylabel('Vibrational Formation Energy (eV)')
% saveas(gcf,'FormaFvib.png')
% FormVibT=[T FormVib];
% save FormaFvibT.txt FormVibT -ascii
%--------------
% FormaTot=FormaFvib+Ef;
% figure(4)
% plot(T,FormaTot,'k','LineWidth',2)
% xlabel('Temperature (K)')
% ylabel('Total Formation Free Energy (eV)')
% saveas(gcf,'TotFormaFreeT.png')
% TotFormaFreeT=[T FormaTot];
% save TotFormaFree.txt TotFormaFreeT -ascii
