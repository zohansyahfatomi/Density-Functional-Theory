close all; clear all;
kB=8.6173324e-5;%8.617e-5; % eV/K  %1.3806488e-23; % J/K 
%h=4.135665538e-15;%4.136e-15;% eV s %6.62606957e-34; % J s
%c=2.99792458e+10;%cm/s %%299792500;
%hc=h*c;
%0.000124
%hperkB=h/kB;
T=[500:1:1685]'; % K
E0=input(' Ef0   = '); %3.46 eV  %4.1
Es=input(' Efs   = '); %3.2 eV   %3.85
%Evib=input(' Fvib = '); % -7.6038358e-003
%E=E0+Evib;
%Nnum=(10.330053*0.529177249*1e-8)^3;
N0=8/(10.330053*0.529177249*1e-8)^3 % cm^-3  % 1e+24 = (1e+8)^3
E0perkB=E0/kB;
EperkB=Es/kB;
ni=3;
vc0=N0*exp(-E0perkB./T);
vc=ni*N0*exp(-EperkB./T);
Vconc=[T vc0 vc];
save VacConc.txt Vconc -ascii
%------------
figure(1)
InvT=1./T;
%semilogy(InvT,vc0,'ko-',InvT,vc,'bo-')
semilogy(InvT,vc,'k','LineWidth',2)
xlabel('Temperature (K)')
ylabel('Vacancy Concentration (cm^-^3)')
%leg1=legend('without S','with S','Tmelt','Tmelt(S)');
%set(leg1,'Location','NorthEast')
%set(leg1,'Location','SouthEast')
saveas(gcf,'VacConc.png')