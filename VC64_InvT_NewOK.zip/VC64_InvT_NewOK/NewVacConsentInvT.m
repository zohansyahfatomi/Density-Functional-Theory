close all; clear all;
kB=8.6173324e-5;%8.617e-5; % eV/K  %1.3806488e-23; % J/K 
h=4.135665538e-15;%4.136e-15;% eV s %6.62606957e-34; % J s
c=2.99792458e+10;%cm/s %%299792500;
hc=h*c;
%0.000124
%hperkB=h/kB;
load ModeFreqP.txt
load ModeFreqV.txt
%Tsi=1685;
T=[10:1:505]'; % K
Np=length(ModeFreqP);
vibp=ModeFreqP(:,1);
hnup=ModeFreqP(:,2); % eV
nup=ModeFreqP(:,3); % cm^-1
%-------------
Nv=length(ModeFreqV);
vibv=ModeFreqV(:,1);
hnuv=ModeFreqV(:,2); % eV
nuv=ModeFreqV(:,3); % cm^-1
for i=1:length(T)
    sump=0;
    for k=1:Np
% %        sump=0;
        %  f0p=exp(-hnup(k)/(kB*T(i)));
       %   f0p1=exp(hnup(k)/(kB*T(i)));
       %  fp=hnup(k)/T(i)/(f0p1-1)-log(1-f0p); %fp=hnup(k)/T(i)*f0p/(1-f0p)-kB*log(1-f0p);
          %---------
        fp=(hnup(k)/2 - T(i)*kB*log(exp(hnup(k)/(2*T(i)*kB))/2 - 1/(2*exp(hnup(k)/(2*T(i)*kB)))))/T(i) + hnup(k)/(T(i)*(exp(hnup(k)/(T(i)*kB)) - 1));
        %fp=(hnup(k)/2 - T(i)*kB*log(exp(hnup(k)/(2*T(i)*kB)) - 1/exp(hnup(k)/(2*T(i)*kB))))/T(i) + hnup(k)/(T(i)*(exp(hnup(k)/(T(i)*kB)) - 1));
        sump=sump+fp;
    end
   %  sumpS=sump*kB; %64
   %  EntP(i,:)=[sumpS];
     EntP(i,:)=[sump];
end
Sp=EntP;
%SpKb=Sp/kB
%--------------------
for i=1:length(T)
     sumv=0;
    for l=1:Nv
% %         sumv=0;
         %  f0v=exp(-hnuv(l)/(kB*T(i)));
         %  f0v1=exp(hnuv(l)/(kB*T(i)));
          % fv=hnuv(l)/T(i)/(f0v1-1)-log(1-f0v); %fv=hnuv(l)/T(i)*f0v/(1-f0v)-kB*log(1-f0v);
           %S=7.0 kB ,  C = 7.3811628e+015 
%--------------------
        fv=(hnuv(l)/2 - T(i)*kB*log(exp(hnuv(l)/(2*T(i)*kB))/2 - 1/(2*exp(hnuv(l)/(2*T(i)*kB)))))/T(i) + hnuv(l)/(T(i)*(exp(hnuv(l)/(T(i)*kB)) - 1)); 
        %S=8.0 kB , C =  1.9554418e+016
        %fv=(hnup(l)/2 - T(i)*kB*log(exp(hnup(l)/(2*T(i)*kB)) - 1/exp(hnup(l)/(2*T(i)*kB))))/T(i) + hnup(l)/(T(i)*(exp(hnup(l)/(T(i)*kB)) - 1));
        sumv=sumv+fv;
    end
     % sumvS=sumv*kB; %/63
     % EntV(i,:)=[sumvS];
      EntV(i,:)=[sumv];
end
Sv=EntV;
%SvKb=Sv/kB;
%delS=abs(SvKb-SpKb);
S=Sv-63/64*Sp;
%S=Sv-Nv/Np*Sp;
%S=abs(Sv-Sp);
SkB=S/kB;
SpKb=Sp/kB;
SvKb=Sv/kB;
E0=input(' Ef0   = '); %3.46 eV 
%Es=input(' Efs   = '); % 2.4273 %-1.0327036e+000
%Evib=input(' Fvib = '); % 0  %-6.4979897e-003
%E=E0+Evib;
%Nnum=(10.330053*0.529177249*1e-8)^3;
%N0=8/(10.330053*0.529177249*1e-8)^3 % cm^-3  % 1e+24 = (1e+8)^3
N0=8/(12.6393366266446*0.529177249*1e-8)^3 % cm^-3  % 1e+24 = (1e+8)^3
E0perkB=E0/kB;
%EperkB=Es/kB;
expSkB=exp(SkB)
%menghitung Vacancy
vc0=N0*exp(-E0perkB./T);
%vc=ni*N0*expSkB.*exp(-E0perkB./T);
vc=N0*expSkB.*exp(-E0perkB./T);
%------------
%vc0Tsi=N0*exp(-EperkB./Tsi)
%vcTsi=ni*N0*expSkB*exp(-EperkB./Tsi)
figure(1)
Vibdata = [vibp,nup,vibv,nuv];
save Vibdata.txt Vibdata -ascii
plot(vibp,nup,'ko-')
hold on
plot(vibv,nuv,'bo-')
xlabel('Vibrational Mode')
ylabel('Frequency (cm^-^1)')
leg0=legend('Perfect','Vacancy');
set(leg0,'Location','NorthWest')
saveas(gcf,'VibpFreq.png')
%--------------
InvT=1./T;
%logA=log(vc0);
%logB=log(vc);
Entropy=[S];
EntropKb=[SkB];
Entropies=[T SpKb SvKb S SkB] ;
Vconc=[InvT vc0 vc];
%Vconc=[T vc0 vc];

save Entropy.txt Entropies -ascii
save VacConc.txt Vconc -ascii
% figure(2)
% plot(vibv,nuv,'bo-')
% xlabel('Vibration Mode')
% ylabel('Frequency (cm^-^1)')
% saveas(gcf,'VibvFreq.png')
% Vconc=[T vc0 vc];
% save VacConc.txt Vconc -ascii
% load VacConc.txt
figure(2)
%InvT=1./T;
% NT=length(T);
% Tend=VacConc(NT,1);
% logvc0end=VacConc(NT,2);
% logvcend=VacConc(NT,3);
semilogy(InvT,vc0,'k--',InvT,vc,'k','LineWidth',2)
%hold on
%plot(Tsi,vcTsi,'ro',Tsi,vc0Tsi,'go','linewidth',3)
xlabel('1/T (K^-^1)')
ylabel('Vacancy Concentration (cm^-^3)')
%leg1=legend('without S','with S','Tmelt','Tmelt(S)');
%set(leg1,'Location','NorthEast')
saveas(gcf,'VacConc.png')
saveas(gcf,'VacConc.eps')
%ylim([2.0052283e-290 1.2640232e+018])
figure(3)
plot(T,Sp,'k','LineWidth',2)
hold on
plot(T,Sv,'b','LineWidth',2)
xlabel('Temperature (K)')
ylabel('Entropy (eV K^-^1)')
leg2=legend('Perfect','Vacancy');
set(leg2,'Location','NorthWest')
saveas(gcf,'Entropy.png')
%-------
figure(4)
plot(T,Entropy,'k','LineWidth',2)
xlabel('Temperature (K)')
ylabel('Vibrational Formation Entropy (eV K^-^1)')
saveas(gcf,'FormaEntropy.png')
figure(5)
plot(T,EntropKb,'k','LineWidth',2)
xlabel('Temperature (K)')
ylabel('Vibrational Formation Entropy (k_B)')
saveas(gcf,'FormaEntropy_kB.png')
saveas(gcf,'FormaEntropy_kB.eps')
%-------
%menghitung Vacancy konsetrasi

Vacdata= [vc0 vc];
save Vacdata.txt Vacdata -ascii