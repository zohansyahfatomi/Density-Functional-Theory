function FvibEntropy
close all; clear all;
%--------------------
kB=8.6173324e-5;%8.617e-5; % eV/K  %1.3806488e-23; % J/K 
h=4.135665538e-15;%4.136e-15;% eV s %6.62606957e-34; % J s
%c=2.99792458e+10;%cm/s %%299792500;
%hc=h*c;
%0.000124
%hperkB=h/kB;
load ModeFreqP.txt
load ModeFreqV.txt
%Tsi=1685;
T=[5:5:1685]'; % K
Np=length(ModeFreqP);
%vibp=ModeFreqP(:,1);
hnup=ModeFreqP(:,2); % eV
%nup=ModeFreqP(:,3); % cm^-1
%-------------
Nv=length(ModeFreqV);
%vibv=ModeFreqV(:,1);
hnuv=ModeFreqV(:,2); % eV
%nuv=ModeFreqV(:,3); % cm^-1
%-----------------
%Np=input(' Number of Atoms Np = ')
%Nv=Np-1
%Ecp=4.63/216%0.0544; % Ec = 4.63 eV
%Ecv=4.63/215
%E0p=0.040153431;
%E0v=0.039392684;
for i=1:length(T)
 %   Cp=exp(Np*Ecp/(kB*T(i)));
    for k=1:Np
        sump=0;
        %Ap=hnup(k)/(2*kB*T(i));
        %fp=log((exp(Ap)-exp(-Ap))/2);
        fp=-(hnup(k)/2 - T(i)*kB*log(exp(hnup(k)/(2*T(i)*kB))/2 - 1/(2*exp(hnup(k)/(2*T(i)*kB)))))/T(i) - hnup(k)/(T(i)*(exp(hnup(k)/(T(i)*kB)) - 1));
        sump=sump+fp;
    end
    %Pvib=kB*T(i)*sump; %Np=3N
    Pvib=sump;
    FP(i,:)=[Pvib];
end
FPvib=FP;%/kB;
%----------------------
for i=1:length(T)
 %   Cp=exp(Np*Ecp/(kB*T(i)));
    for k=1:Nv
        sumv=0;
        %Av=hnuv(k)/(2*kB*T(i));
        %fv=log((exp(Av)-exp(-Av))/2);
        fv=-(hnuv(k)/2 - T(i)*kB*log(exp(hnuv(k)/(2*T(i)*kB))/2 - 1/(2*exp(hnuv(k)/(2*T(i)*kB)))))/T(i) - hnuv(k)/(T(i)*(exp(hnuv(k)/(T(i)*kB)) - 1));
        sumv=sumv+fv;
    end
    %Vvib=kB*T(i)*sumv;
    Vvib=sumv;
    FV(i,:)=[Vvib];
end
FVvib=FV;%/kB;
%----------------------
FormaFvib=215*abs(FVvib-FPvib);
FormaFvibKb=FormaFvib/kB;
%FormaFvib=FVvib-215/216*FPvib;
figure(1)
plot(T,FormaFvib,'k','LineWidth',2)
xlabel('Temperature (K)')
ylabel('Vibrational Formation Entropy (eV K^-^1)')
saveas(gcf,'FormaEntropy.png')
FormaFvibT=[T FormaFvib];
save FormaEntropyT.txt FormaFvibT -ascii
%------------
figure(2)
plot(T,FormaFvibKb,'k','LineWidth',2)
xlabel('Temperature (K)')
ylabel('Vibrational Formation Entropy (k_B)')
saveas(gcf,'FormaEntropyKb.png')
FormaFvibKbT=[T FormaFvibKb];
save FormaEntropyKbT.txt FormaFvibKbT -ascii
