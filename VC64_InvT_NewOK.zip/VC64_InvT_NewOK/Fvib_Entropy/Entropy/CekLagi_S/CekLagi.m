close all; clear all;
kB=8.6173324e-5;%8.617e-5; % eV/K  %1.3806488e-23; % J/K 
%h=4.135665538e-15;%4.136e-15;% eV s %6.62606957e-34; % J s
%c=2.99792458e+10;%cm/s %%299792500;
%hc=h*c;
%0.000124
%hperkB=h/kB;
load ModeFreqP.txt
load ModeFreqV.txt
Tsi=1685;
T=[505:5:1685]'; % K
Np=length(ModeFreqP);
vibp=ModeFreqP(:,1);
hnup=ModeFreqP(:,2); % eV
nup=ModeFreqP(:,3); % cm^-1
%-------------
Nv=length(ModeFreqV);
vibv=ModeFreqV(:,1);
hnuv=ModeFreqV(:,2); % eV
nuv=ModeFreqV(:,3); % cm^-1
for i=1:length(T)
    for k=1:Np
        sump=0;
        f0p=exp(-hnup(k)/(kB*T(i)));
        fp=hnup(k)/T(i)*f0p/(1-f0p)-kB*log(1-f0p);
        %fp=-(hnup(k)/2 - T(i)*kB*log(exp(hnup(k)/(2*T(i)*kB))/2 - 1/(2*exp(hnup(k)/(2*T(i)*kB)))))/T(i) - hnup(k)/(T(i)*(exp(hnup(k)/(T(i)*kB)) - 1));
        sump=sump+fp;
    end
    EntP(i,:)=[sump];
end
Sp=EntP;
%SpKb=Sp/kB;
%--------------------
for i=1:length(T)
    for l=1:Nv
        sumv=0;
        f0v=exp(-hnuv(l)/(kB*T(i)));
        fv=hnuv(l)/T(i)*f0v/(1-f0v)-kB*log(1-f0v);
        %fv=-(hnuv(l)/2 - T(i)*kB*log(exp(hnuv(l)/(2*T(i)*kB))/2 - 1/(2*exp(hnuv(l)/(2*T(i)*kB)))))/T(i) - hnuv(l)/(T(i)*(exp(hnuv(l)/(T(i)*kB)) - 1));
        sumv=sumv+fv;
    end
    EntV(i,:)=[sumv];
end
Sv=EntV;
%SvKb=Sv/kB;
%Spp=SpKb(length(T))
%delS=abs(SvKb-SpKb);
S=215*abs(Sv-Sp);
SkB=S/kB
%--------------
Entropy=[S];
EntropKb=[SkB];
%Vconc=[T vc0 vc];
save Entropy.txt Entropy -ascii
save EntropyKb.txt EntropKb -ascii
%save VacConc.txt Vconc -ascii
figure(1)
plot(T,Entropy,'ko-')
xlabel('Temperature (K)')
ylabel('Vibrational Formation Entropy (eV K^-^1)')
saveas(gcf,'Entropy.png')
figure(2)
plot(T,EntropKb,'ko-')
xlabel('Temperature (K)')
ylabel('Vibrational Formation Entropy (k_B)')
saveas(gcf,'Entrop_kB.png')