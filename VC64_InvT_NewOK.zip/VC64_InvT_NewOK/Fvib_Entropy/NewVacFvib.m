close all; clear all;
FvibForma;
kB=8.6173324e-5;%8.617e-5; % eV/K  %1.3806488e-23; % J/K 
h=4.135665538e-15;%4.136e-15;% eV s %6.62606957e-34; % J s
c=2.99792458e+10;%cm/s %%299792500;
hc=h*c;
load FvibT.txt
T=FvibT(:,1); % K
Evib=FvibT(:,2);
%-------------
E0=input(' Ef0   = '); %3.46 eV
E0Evib=E0+Evib;
N0=8/(10.330053*0.529177249*1e-8)^3 % cm^-3  % 1e+24 = (1e+8)^3
E0perkB=E0/kB;
EvibperkB=E0Evib/kB;
ni=3;
vc0=N0*exp(-E0perkB./T);
vc=ni*N0.*exp(-EvibperkB./T);
%------------
figure(3)
InvT=1./T;
% NT=length(T);
% Tend=VacConc(NT,1);
% logvc0end=VacConc(NT,2);
% logvcend=VacConc(NT,3);
semilogy(InvT,vc0,'k',InvT,vc,'b','LineWidth',2)
%hold on
%plot(Tsi,vcTsi,'ro',Tsi,vc0Tsi,'go','linewidth',3)
xlabel('Temperature (K)')
ylabel('Vacancy Concentration (cm^-^3)')
leg1=legend('without S','with S','Tmelt','Tmelt(S)');
%set(leg1,'Location','NorthEast')
%set(leg1,'Location','SouthEast')
saveas(gcf,'VacConc.png')
%ylim([2.0052283e-290 1.2640232e+018])
Vconc=[T InvT vc0 vc];
save VacConc.txt Vconc -ascii
%---
%---
%---
%open VacConc.txt